"""
Optimization Agent
Provides suggestions to optimize user engagement and performance
"""

from typing import Dict, List, Any
from datetime import datetime, timedelta


class OptimizationAgent:
    """
    Analyzes user data and provides optimization suggestions
    to improve engagement and performance.
    
    Optimization Areas:
    - Time Management
    - Activity Pattern Optimization
    - Difficulty Adjustment
    - Reward Strategy
    - Engagement Recovery
    """
    
    def __init__(self):
        """Initialize optimization agent"""
        self.name = "Optimization Agent"
        self.version = "1.0"
        self.description = "Provides optimization suggestions for engagement improvement"
        print(f"[{self.name}] Initialized")
    
    def suggest_optimizations(self, user: Dict, activities: List, 
                             metrics: List, challenges: List) -> Dict[str, Any]:
        """
        Generate optimization suggestions
        
        Args:
            user: User dictionary
            activities: List of user activities
            metrics: List of engagement metrics
            challenges: List of challenges
            
        Returns:
            Dictionary with optimization suggestions
        """
        suggestions = []
        priority_areas = []
        
        # Analyze activity patterns
        pattern_suggestions = self._analyze_activity_patterns(activities)
        suggestions.extend(pattern_suggestions)
        
        # Analyze time investment
        time_suggestions = self._analyze_time_investment(activities)
        suggestions.extend(time_suggestions)
        
        # Analyze challenge difficulty
        difficulty_suggestions = self._analyze_challenge_difficulty(challenges)
        suggestions.extend(difficulty_suggestions)
        
        # Analyze engagement trends
        trend_suggestions = self._analyze_engagement_trends(metrics)
        suggestions.extend(trend_suggestions)
        
        # Identify priority areas
        priority_areas = self._identify_priority_areas(activities, metrics)
        
        # Generate action plan
        action_plan = self._generate_action_plan(suggestions, user)
        
        return {
            'suggestions': suggestions,
            'priority_areas': priority_areas,
            'action_plan': action_plan,
            'estimated_improvement': self._estimate_improvement(suggestions),
            'generated_at': datetime.utcnow().isoformat()
        }
    
    def _analyze_activity_patterns(self, activities: List) -> List[Dict[str, Any]]:
        """Analyze user's activity patterns"""
        suggestions = []
        
        if not activities:
            return [{
                'category': 'Activity Pattern',
                'priority': 'high',
                'suggestion': 'Start building your activity pattern - try 2-3 activities per week',
                'potential_impact': 'High',
                'estimated_points': 100
            }]
        
        # Analyze day of week preferences
        activity_days = self._get_activity_days(activities)
        most_active_day = max(set(activity_days), key=activity_days.count) if activity_days else None
        
        # Suggest optimal schedule
        if len(activity_days) < 4:
            suggestions.append({
                'category': 'Activity Pattern',
                'priority': 'high',
                'suggestion': f'You\'re most active on {most_active_day}s. Try to add activity on other days too.',
                'potential_impact': 'High',
                'estimated_points': 75,
                'action': 'Increase activity frequency to 4+ days per week'
            })
        
        # Analyze time gaps
        time_gaps = self._calculate_time_gaps(activities)
        if time_gaps and max(time_gaps) > 7:
            suggestions.append({
                'category': 'Consistency',
                'priority': 'medium',
                'suggestion': f'You had a {max(time_gaps)} day gap. Try to maintain activity every 3-4 days.',
                'potential_impact': 'Medium',
                'estimated_points': 50,
                'action': 'Set daily login reminders'
            })
        
        return suggestions
    
    def _get_activity_days(self, activities: List) -> List[str]:
        """Get days of week for activities"""
        days_map = {0: 'Monday', 1: 'Tuesday', 2: 'Wednesday', 3: 'Thursday', 
                   4: 'Friday', 5: 'Saturday', 6: 'Sunday'}
        
        days = []
        for activity in activities:
            created_at = getattr(activity, 'created_at', None)
            if created_at:
                day_num = created_at.weekday()
                days.append(days_map.get(day_num, 'Unknown'))
        
        return days
    
    def _calculate_time_gaps(self, activities: List) -> List[int]:
        """Calculate gaps between activities in days"""
        if len(activities) < 2:
            return []
        
        dates = sorted([getattr(a, 'created_at', datetime.utcnow()) for a in activities])
        gaps = []
        
        for i in range(len(dates) - 1):
            gap_days = (dates[i + 1] - dates[i]).days
            if gap_days > 0:
                gaps.append(gap_days)
        
        return gaps
    
    def _analyze_time_investment(self, activities: List) -> List[Dict[str, Any]]:
        """Analyze user's time investment"""
        suggestions = []
        
        total_minutes = sum(getattr(a, 'duration_minutes', 0) for a in activities)
        total_hours = total_minutes / 60
        
        # Calculate average time per activity
        avg_time = total_minutes / len(activities) if activities else 0
        
        if total_hours < 5:
            suggestions.append({
                'category': 'Time Investment',
                'priority': 'medium',
                'suggestion': f'You\'ve invested {total_hours:.1f} hours total. Aim for at least 15-20 minutes per session.',
                'potential_impact': 'Medium',
                'estimated_points': 60,
                'action': 'Increase time per session to 20-30 minutes'
            })
        
        if avg_time < 15:
            suggestions.append({
                'category': 'Session Duration',
                'priority': 'low',
                'suggestion': f'Your average session is {avg_time:.0f} minutes. Consider dedicating 20-30 minutes per session.',
                'potential_impact': 'Low',
                'estimated_points': 40,
                'action': 'Block out dedicated study time'
            })
        
        return suggestions
    
    def _analyze_challenge_difficulty(self, challenges: List) -> List[Dict[str, Any]]:
        """Analyze challenge difficulty appropriateness"""
        suggestions = []
        
        if not challenges:
            return []
        
        completed_challenges = [c for c in challenges if getattr(c, 'status', '') == 'completed']
        failed_challenges = [c for c in challenges if getattr(c, 'status', '') == 'failed']
        
        # Calculate success rate
        success_rate = len(completed_challenges) / len(challenges) if challenges else 0
        
        if success_rate < 0.3:
            suggestions.append({
                'category': 'Challenge Difficulty',
                'priority': 'high',
                'suggestion': 'Your difficulty might be too high. Try easier challenges first.',
                'potential_impact': 'High',
                'estimated_points': 80,
                'action': 'Switch to medium difficulty challenges'
            })
        elif success_rate > 0.8:
            suggestions.append({
                'category': 'Challenge Difficulty',
                'priority': 'low',
                'suggestion': 'You\'re crushing challenges! Try harder difficulties to stay challenged.',
                'potential_impact': 'Medium',
                'estimated_points': 100,
                'action': 'Increase to hard difficulty'
            })
        
        return suggestions
    
    def _analyze_engagement_trends(self, metrics: List) -> List[Dict[str, Any]]:
        """Analyze engagement trends over time"""
        suggestions = []
        
        if len(metrics) < 2:
            return suggestions
        
        # Sort by time
        sorted_metrics = sorted(metrics, key=lambda m: getattr(m, 'recorded_at', datetime.utcnow()))
        
        # Compare recent to older
        recent = sorted_metrics[-1]
        older = sorted_metrics[0]
        
        recent_score = getattr(recent, 'engagement_score', 0)
        older_score = getattr(older, 'engagement_score', 0)
        
        score_change = recent_score - older_score
        
        if score_change < -10:
            suggestions.append({
                'category': 'Engagement Trend',
                'priority': 'high',
                'suggestion': f'Your engagement is declining (-{abs(score_change):.1f} points). Let\'s reverse this trend!',
                'potential_impact': 'High',
                'estimated_points': 150,
                'action': 'Take on a new challenge to reignite engagement'
            })
        elif score_change > 10:
            suggestions.append({
                'category': 'Engagement Trend',
                'priority': 'low',
                'suggestion': f'Great! Your engagement is improving (+{score_change:.1f} points). Keep it up!',
                'potential_impact': 'Medium',
                'estimated_points': 50,
                'action': 'Maintain your current pace'
            })
        
        return suggestions
    
    def _identify_priority_areas(self, activities: List, metrics: List) -> List[str]:
        """Identify priority improvement areas"""
        priority_areas = []
        
        if not activities:
            priority_areas.append('Build consistent activity pattern')
            priority_areas.append('Start with easy challenges')
            return priority_areas
        
        # Check for weak areas
        if len(activities) < 5:
            priority_areas.append('Increase activity frequency')
        
        avg_time = sum(getattr(a, 'duration_minutes', 0) for a in activities) / len(activities)
        if avg_time < 15:
            priority_areas.append('Extend session duration')
        
        if not metrics or all(getattr(m, 'engagement_score', 0) < 50 for m in metrics):
            priority_areas.append('Improve engagement score')
        
        if not priority_areas:
            priority_areas.append('Maintain current momentum')
            priority_areas.append('Challenge yourself with harder content')
        
        return priority_areas
    
    def _generate_action_plan(self, suggestions: List, user: Dict) -> List[Dict[str, Any]]:
        """Generate actionable plan from suggestions"""
        action_plan = []
        
        # Sort by priority
        high_priority = [s for s in suggestions if s.get('priority') == 'high']
        medium_priority = [s for s in suggestions if s.get('priority') == 'medium']
        low_priority = [s for s in suggestions if s.get('priority') == 'low']
        
        # Create action items
        week_num = 1
        for suggestion in high_priority[:2]:  # Top 2 high priority
            action_plan.append({
                'week': week_num,
                'action': suggestion.get('action', 'Complete suggested challenge'),
                'goal': f"Increase engagement by {suggestion.get('estimated_points', 50)} points",
                'timeframe': 'This week'
            })
            week_num += 1
        
        for suggestion in medium_priority[:1]:  # Top 1 medium priority
            action_plan.append({
                'week': week_num,
                'action': suggestion.get('action', 'Continue optimization'),
                'goal': f"Improve by {suggestion.get('estimated_points', 30)} points",
                'timeframe': 'Next week'
            })
            week_num += 1
        
        return action_plan
    
    def _estimate_improvement(self, suggestions: List) -> Dict[str, Any]:
        """Estimate potential improvement from suggestions"""
        if not suggestions:
            return {'points': 0, 'engagement_increase': 0, 'level_increase': 0}
        
        total_potential_points = sum(s.get('estimated_points', 0) for s in suggestions)
        
        return {
            'points': total_potential_points,
            'engagement_increase': min(30, len(suggestions) * 5),
            'level_increase': min(2, total_potential_points // 300),
            'timeframe_days': 14
        }
    
    def get_personalized_recommendation(self, user: Dict, engagement_score: float) -> str:
        """Get personalized recommendation for user"""
        if engagement_score < 20:
            return "Start small with daily 15-minute sessions to build consistency"
        elif engagement_score < 40:
            return "Try mixing different activity types to stay engaged"
        elif engagement_score < 60:
            return "You're on the right track! Consider joining study groups"
        elif engagement_score < 80:
            return "Great work! Try harder challenges to push yourself further"
        else:
            return "You're a power user! Consider mentoring others in the community"
