"""
Challenge Agent
Generates personalized challenges to improve user engagement
"""

from typing import Dict, List, Any
from datetime import datetime, timedelta
import random


class ChallengeAgent:
    """
    Generates personalized challenges based on user engagement and preferences.
    
    Challenge Types:
    - Daily Challenges (complete daily activities)
    - Weekly Challenges (complete multiple activities)
    - Skill Challenges (focused on specific skills)
    - Streak Challenges (maintain engagement streaks)
    - Achievement Challenges (unlock badges)
    """
    
    def __init__(self):
        """Initialize challenge agent"""
        self.name = "Challenge Agent"
        self.version = "1.0"
        self.description = "Generates personalized challenges to boost engagement"
        
        self.challenge_templates = {
            'daily': {
                'titles': [
                    'Daily Grind',
                    'Day Starter',
                    'Morning Mission',
                    'Quick Win',
                    'Daily Sprint'
                ],
                'difficulty': 'easy',
                'points': 10,
                'days_to_complete': 1
            },
            'weekly': {
                'titles': [
                    'Weekly Challenge',
                    'Week Warrior',
                    'Consistency Check',
                    'Achievement Week',
                    'Power Week'
                ],
                'difficulty': 'medium',
                'points': 50,
                'days_to_complete': 7
            },
            'skill': {
                'titles': [
                    'Skill Builder',
                    'Master Class',
                    'Deep Dive',
                    'Expert Challenge',
                    'Skill Sprint'
                ],
                'difficulty': 'hard',
                'points': 100,
                'days_to_complete': 14
            },
            'streak': {
                'titles': [
                    'Streak Keeper',
                    'Consistency King',
                    'Unstoppable',
                    'On Fire',
                    'Momentum Master'
                ],
                'difficulty': 'medium',
                'points': 75,
                'days_to_complete': 7
            }
        }
        
        print(f"[{self.name}] Initialized")
    
    def generate_challenges(self, user: Dict, engagement_score: float, 
                           activities: List) -> Dict[str, Any]:
        """
        Generate personalized challenges for user
        
        Args:
            user: User dictionary
            engagement_score: Current engagement score (0-100)
            activities: List of user activities
            
        Returns:
            Dictionary with challenges
        """
        challenges = []
        challenge_count = self._determine_challenge_count(engagement_score)
        
        # Generate daily challenge
        challenges.append(self._generate_daily_challenge(user))
        
        # Generate engagement-based challenge
        if engagement_score < 50:
            challenges.append(self._generate_boost_challenge(user))
        
        # Generate streak challenge
        challenges.append(self._generate_streak_challenge(user))
        
        # Generate skill development challenge
        challenges.append(self._generate_skill_challenge(user, activities))
        
        # Generate specific challenges based on activity history
        if self._has_quiz_history(activities):
            challenges.append(self._generate_quiz_challenge(user))
        
        return {
            'challenges': challenges[:challenge_count],
            'total_challenges': len(challenges),
            'recommended_count': challenge_count,
            'motivation_message': self._get_motivation_message(engagement_score),
            'generated_at': datetime.utcnow().isoformat()
        }
    
    def _determine_challenge_count(self, engagement_score: float) -> int:
        """Determine how many challenges to generate"""
        if engagement_score < 20:
            return 2  # Low engagement - start small
        elif engagement_score < 50:
            return 3
        elif engagement_score < 75:
            return 4
        else:
            return 5  # High engagement - more challenges
    
    def _generate_daily_challenge(self, user: Dict) -> Dict[str, Any]:
        """Generate daily challenge"""
        template = self.challenge_templates['daily']
        
        return {
            'type': 'daily',
            'title': random.choice(template['titles']),
            'description': 'Complete at least one learning activity today',
            'difficulty': template['difficulty'],
            'points': template['points'],
            'days_to_complete': template['days_to_complete'],
            'tasks': [
                'Log in to the platform',
                'Complete one quiz or study session',
                'Spend at least 15 minutes learning'
            ],
            'xp_reward': 50,
            'streak_bonus': 5
        }
    
    def _generate_boost_challenge(self, user: Dict) -> Dict[str, Any]:
        """Generate engagement boost challenge"""
        template = self.challenge_templates['weekly']
        
        return {
            'type': 'engagement_boost',
            'title': 'Engagement Boost Challenge',
            'description': f"We noticed your engagement is low. Let's boost it up!",
            'difficulty': template['difficulty'],
            'points': 75,
            'days_to_complete': 7,
            'tasks': [
                'Complete 3 quizzes',
                'Spend 30 minutes learning',
                'Log in 5 days this week',
                'Share your progress with a friend'
            ],
            'xp_reward': 200,
            'milestone_reward': 'Comeback Badge'
        }
    
    def _generate_streak_challenge(self, user: Dict) -> Dict[str, Any]:
        """Generate streak maintenance challenge"""
        template = self.challenge_templates['streak']
        current_streak = user.get('current_streak', 0)
        
        return {
            'type': 'streak',
            'title': f"Keep the {current_streak} Day Streak Alive!",
            'description': f'Maintain your {current_streak} day streak by logging in daily',
            'difficulty': template['difficulty'],
            'points': 50 + (current_streak // 2),
            'days_to_complete': 7,
            'tasks': [
                'Log in every day this week',
                'Complete at least one activity daily',
                'Maintain focus on your learning goals'
            ],
            'xp_reward': 150,
            'streak_bonus': current_streak * 2
        }
    
    def _generate_skill_challenge(self, user: Dict, activities: List) -> Dict[str, Any]:
        """Generate skill development challenge"""
        template = self.challenge_templates['skill']
        
        # Determine skill focus based on activities
        skill_focus = self._determine_skill_focus(activities)
        
        return {
            'type': 'skill_development',
            'title': f'Master {skill_focus}',
            'description': f'Deepen your {skill_focus} skills through focused practice',
            'difficulty': template['difficulty'],
            'points': template['points'],
            'days_to_complete': template['days_to_complete'],
            'tasks': [
                f'Complete 5 {skill_focus} related activities',
                'Achieve 80% or higher on all quizzes',
                'Document your learning progress',
                'Complete a final assessment'
            ],
            'xp_reward': 500,
            'milestone_reward': f'{skill_focus} Expert Badge'
        }
    
    def _generate_quiz_challenge(self, user: Dict) -> Dict[str, Any]:
        """Generate quiz-focused challenge"""
        return {
            'type': 'quiz',
            'title': 'Quiz Master Challenge',
            'description': 'Test your knowledge with our quiz series',
            'difficulty': 'medium',
            'points': 75,
            'days_to_complete': 14,
            'tasks': [
                'Complete 10 quizzes',
                'Achieve average score of 75%+',
                'Complete all difficulty levels'
            ],
            'xp_reward': 300,
            'milestone_reward': 'Quiz Master Badge'
        }
    
    def _determine_skill_focus(self, activities: List) -> str:
        """Determine which skill to focus on based on activity history"""
        if not activities:
            return 'Python Programming'
        
        skill_tags = {
            'quiz': 'Knowledge Testing',
            'challenge': 'Problem Solving',
            'study': 'Core Concepts',
            'project': 'Project Building'
        }
        
        activity_types = [getattr(a, 'activity_type', 'unknown') for a in activities]
        most_common = max(set(activity_types), key=activity_types.count) if activity_types else 'Programming'
        
        return skill_tags.get(most_common, 'Advanced Programming')
    
    def _has_quiz_history(self, activities: List) -> bool:
        """Check if user has taken quizzes"""
        return any(getattr(a, 'activity_type', '') == 'quiz' for a in activities)
    
    def _get_motivation_message(self, engagement_score: float) -> str:
        """Get motivational message based on engagement"""
        if engagement_score < 20:
            return "Let's get you back on track! Start with the daily challenge."
        elif engagement_score < 50:
            return "You're making progress! Keep the momentum going."
        elif engagement_score < 75:
            return "Great engagement! Ready to level up?"
        else:
            return "You're crushing it! Take on all the challenges!"
    
    def recommend_challenge_difficulty(self, engagement_score: float, streak: int) -> str:
        """Recommend challenge difficulty level"""
        if engagement_score < 30 or streak < 3:
            return 'easy'
        elif engagement_score < 60 or streak < 7:
            return 'medium'
        else:
            return 'hard'
    
    def get_challenge_progression(self, user_level: int) -> List[Dict[str, Any]]:
        """Get suggested challenge progression for user level"""
        progressions = {
            1: ['Complete 1 quiz', 'Log in 3 days', 'Earn 50 points'],
            2: ['Complete 3 quizzes', 'Log in 7 days', 'Earn 200 points'],
            3: ['Complete 5 quizzes', 'Maintain 7-day streak', 'Complete 1 challenge'],
            4: ['Complete 10 quizzes', 'Maintain 14-day streak', 'Complete 5 challenges'],
            5: ['Master 2 skills', 'Maintain 30-day streak', 'Earn 1000 points']
        }
        
        if user_level > 5:
            user_level = 5
        
        return progressions.get(user_level, [])
    
    def estimate_completion_time(self, challenge_type: str, difficulty: str) -> int:
        """
        Estimate time to complete challenge in minutes
        
        Args:
            challenge_type: Type of challenge
            difficulty: Difficulty level
            
        Returns:
            Estimated time in minutes
        """
        base_times = {
            'daily': 15,
            'weekly': 60,
            'skill': 120,
            'quiz': 30,
            'project': 180
        }
        
        difficulty_multiplier = {
            'easy': 0.8,
            'medium': 1.0,
            'hard': 1.5
        }
        
        base_time = base_times.get(challenge_type, 30)
        multiplier = difficulty_multiplier.get(difficulty, 1.0)
        
        return int(base_time * multiplier)
