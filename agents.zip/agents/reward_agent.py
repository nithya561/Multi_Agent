"""
Reward Agent
Generates personalized rewards based on user activities and engagement
"""

from typing import Dict, List, Any
from datetime import datetime


class RewardAgent:
    """
    Generates and manages rewards for user activities.
    
    Reward Types:
    - Points (base rewards)
    - Streak Bonuses
    - Badge Unlocks
    - Milestone Rewards
    - Bonus Events
    """
    
    def __init__(self):
        """Initialize reward agent"""
        self.name = "Reward Agent"
        self.version = "1.0"
        self.description = "Generates personalized rewards for user activities"
        
        # Reward configuration
        self.reward_config = {
            'quiz': {'base_points': 10, 'multiplier': 1.5},
            'challenge': {'base_points': 25, 'multiplier': 2.0},
            'login': {'base_points': 5, 'multiplier': 1.0},
            'study': {'base_points': 15, 'multiplier': 1.0},
            'streak_bonus': {'points_per_day': 2, 'max_days': 30},
        }
        
        print(f"[{self.name}] Initialized")
    
    def generate_rewards(self, user: Dict, activity_type: str, 
                        points_earned: int = 0, bonus_multiplier: float = 1.0) -> Dict[str, Any]:
        """
        Generate rewards for a user activity
        
        Args:
            user: User dictionary
            activity_type: Type of activity (quiz, challenge, login, study)
            points_earned: Base points earned
            bonus_multiplier: Multiplier for special events
            
        Returns:
            Dictionary with reward information
        """
        rewards = []
        total_points = 0
        
        # Calculate base reward
        if activity_type in self.reward_config:
            config = self.reward_config[activity_type]
            calculated_points = config['base_points'] * config.get('multiplier', 1.0) * bonus_multiplier
        else:
            calculated_points = points_earned if points_earned > 0 else 10
        
        calculated_points = int(calculated_points)
        total_points += calculated_points
        
        # Add base points reward
        rewards.append({
            'type': 'points',
            'name': f'{activity_type.capitalize()} Reward',
            'amount': calculated_points,
            'description': f'Points for completing {activity_type}'
        })
        
        # Check for streak bonus
        current_streak = user.get('current_streak', 0)
        if current_streak > 0 and current_streak % 5 == 0:
            streak_bonus = current_streak * 2
            total_points += streak_bonus
            rewards.append({
                'type': 'bonus',
                'name': f'{current_streak}-Day Streak Bonus',
                'amount': streak_bonus,
                'description': f'Bonus for {current_streak} day streak'
            })
        
        # Check for badge unlock
        badge_info = self._check_badge_unlock(user, activity_type, total_points)
        if badge_info:
            rewards.append(badge_info)
        
        # Check for milestone
        user_points = user.get('points', 0)
        milestone = self._check_milestone(user_points + total_points)
        if milestone:
            rewards.append(milestone)
        
        return {
            'rewards': rewards,
            'total_points': total_points,
            'total_reward_type': 'mixed' if len(rewards) > 1 else rewards[0]['type'] if rewards else 'none',
            'reward_summary': f'Earned {total_points} points and {len(rewards) - 1} bonus rewards!' 
                            if len(rewards) > 1 else f'Earned {total_points} points!',
            'generated_at': datetime.utcnow().isoformat()
        }
    
    def _check_badge_unlock(self, user: Dict, activity_type: str, points: int) -> Dict[str, Any] or None:
        """
        Check if user unlocked a badge
        
        Args:
            user: User dictionary
            activity_type: Type of activity
            points: Points earned
            
        Returns:
            Badge info or None
        """
        user_level = user.get('level', 1)
        user_points = user.get('points', 0)
        new_total = user_points + points
        
        # Milestone badges
        if new_total >= 100 and user_points < 100:
            return {
                'type': 'badge',
                'name': 'Century Club',
                'icon': 'badge-100',
                'description': 'Earned 100 points',
                'rarity': 'common'
            }
        
        if new_total >= 500 and user_points < 500:
            return {
                'type': 'badge',
                'name': 'Elite Member',
                'icon': 'badge-500',
                'description': 'Earned 500 points',
                'rarity': 'rare'
            }
        
        if new_total >= 1000 and user_points < 1000:
            return {
                'type': 'badge',
                'name': 'Legendary',
                'icon': 'badge-1000',
                'description': 'Earned 1000 points',
                'rarity': 'epic'
            }
        
        # Activity-specific badges
        if activity_type == 'quiz':
            return {
                'type': 'badge',
                'name': 'Quiz Master',
                'icon': 'badge-quiz',
                'description': 'Complete 10 quizzes',
                'rarity': 'common'
            }
        
        if activity_type == 'challenge':
            return {
                'type': 'badge',
                'name': 'Challenge Accepted',
                'icon': 'badge-challenge',
                'description': 'Complete 5 challenges',
                'rarity': 'uncommon'
            }
        
        return None
    
    def _check_milestone(self, total_points: int) -> Dict[str, Any] or None:
        """
        Check for milestone achievements
        
        Args:
            total_points: Total points for user
            
        Returns:
            Milestone info or None
        """
        milestones = {
            100: {'name': 'Century Club', 'reward': 50},
            250: {'name': 'Quarter-Thousand', 'reward': 75},
            500: {'name': 'Elite', 'reward': 100},
            1000: {'name': 'Legendary', 'reward': 200},
        }
        
        # Check if milestone reached
        for points, milestone in milestones.items():
            if total_points == points:
                return {
                    'type': 'milestone',
                    'name': milestone['name'],
                    'description': f'Reached {points} points milestone',
                    'bonus_points': milestone['reward']
                }
        
        return None
    
    def calculate_level(self, points: int) -> int:
        """
        Calculate user level based on points
        
        Args:
            points: Total points
            
        Returns:
            User level
        """
        if points < 100:
            return 1
        elif points < 300:
            return 2
        elif points < 600:
            return 3
        elif points < 1000:
            return 4
        elif points < 1500:
            return 5
        else:
            return 6 + (points - 1500) // 1000
    
    def get_next_reward_milestone(self, current_points: int) -> Dict[str, Any]:
        """
        Get information about next reward milestone
        
        Args:
            current_points: Current points
            
        Returns:
            Next milestone information
        """
        milestones = [100, 250, 500, 1000, 1500, 2000]
        
        for milestone in milestones:
            if current_points < milestone:
                return {
                    'next_milestone': milestone,
                    'points_needed': milestone - current_points,
                    'reward_preview': f'Unlock special badge at {milestone} points'
                }
        
        return {
            'next_milestone': None,
            'points_needed': 0,
            'reward_preview': 'You have reached the maximum level!'
        }
    
    def generate_streak_bonus(self, streak_days: int) -> int:
        """
        Calculate streak bonus
        
        Args:
            streak_days: Number of consecutive days
            
        Returns:
            Bonus points
        """
        base_bonus = 2
        bonus = base_bonus * streak_days
        
        # Extra multiplier for long streaks
        if streak_days >= 7:
            bonus = int(bonus * 1.5)
        if streak_days >= 14:
            bonus = int(bonus * 2.0)
        if streak_days >= 30:
            bonus = int(bonus * 2.5)
        
        return bonus
    
    def apply_special_event_multiplier(self, points: int, event_name: str) -> int:
        """
        Apply special event multipliers
        
        Args:
            points: Base points
            event_name: Name of special event
            
        Returns:
            Modified points
        """
        multipliers = {
            'weekend_bonus': 1.5,
            'holiday_special': 2.0,
            'seasonal_event': 1.25,
            'achievement_day': 1.75,
        }
        
        multiplier = multipliers.get(event_name, 1.0)
        return int(points * multiplier)
