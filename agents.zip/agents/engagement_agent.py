"""
Engagement Agent
Analyzes user activity and calculates engagement scores
"""

from datetime import datetime, timedelta
from typing import List, Dict, Any


class EngagementAgent:
    """
    Analyzes user engagement patterns and provides engagement metrics.
    
    Engagement Score Calculation:
    - Activity frequency (40%)
    - Streak consistency (30%)
    - Time investment (20%)
    - Activity variety (10%)
    """
    
    def __init__(self):
        """Initialize engagement agent"""
        self.name = "Engagement Agent"
        self.version = "1.0"
        self.description = "Analyzes user engagement patterns and calculates engagement metrics"
        print(f"[{self.name}] Initialized")
    
    def analyze_engagement(self, user: Dict, activities: List) -> Dict[str, Any]:
        """
        Comprehensive engagement analysis
        
        Args:
            user: User dictionary with user data
            activities: List of UserActivity objects
            
        Returns:
            Dictionary with engagement analysis
        """
        if not activities:
            return {
                'engagement_score': 0,
                'activities_count': 0,
                'total_time_minutes': 0,
                'daily_active': False,
                'activity_breakdown': {},
                'streak_info': {'current': user.get('current_streak', 0), 'longest': user.get('longest_streak', 0)},
                'recommendations': ['Complete your first activity to start building your streak!']
            }
        
        # Convert activities to list if needed
        if not isinstance(activities, list):
            activities = list(activities)
        
        # Calculate metrics
        engagement_score = self.calculate_engagement_score(activities)
        activities_count = len(activities)
        total_time = sum(getattr(a, 'duration_minutes', 0) for a in activities)
        daily_active = self._check_daily_active(activities)
        activity_breakdown = self._get_activity_breakdown(activities)
        
        return {
            'engagement_score': round(engagement_score, 2),
            'activities_count': activities_count,
            'total_time_minutes': total_time,
            'daily_active': daily_active,
            'activity_breakdown': activity_breakdown,
            'streak_info': {
                'current': user.get('current_streak', 0),
                'longest': user.get('longest_streak', 0)
            },
            'recommendations': self._generate_recommendations(engagement_score, activity_breakdown),
            'analysis_timestamp': datetime.utcnow().isoformat()
        }
    
    def calculate_engagement_score(self, activities: List) -> float:
        """
        Calculate engagement score from 0-100
        
        Args:
            activities: List of UserActivity objects
            
        Returns:
            Engagement score (0-100)
        """
        if not activities:
            return 0.0
        
        # Convert to list if needed
        if not isinstance(activities, list):
            activities = list(activities)
        
        if len(activities) == 0:
            return 0.0
        
        # Metric 1: Activity Frequency (40%) - activities per week
        activities_per_week = len([a for a in activities 
                                   if getattr(a, 'created_at', None) 
                                   and getattr(a, 'created_at').date() 
                                   >= (datetime.utcnow() - timedelta(days=7)).date()]) / 7
        frequency_score = min(100, activities_per_week * 10)
        
        # Metric 2: Consistency (30%) - consecutive days active
        consecutive_days = self._calculate_consecutive_days(activities)
        consistency_score = min(100, consecutive_days * 5)
        
        # Metric 3: Time Investment (20%) - total hours
        total_minutes = sum(getattr(a, 'duration_minutes', 0) for a in activities)
        time_score = min(100, (total_minutes / 60) * 10)  # 10 points per hour
        
        # Metric 4: Activity Variety (10%) - different types
        activity_types = len(set(getattr(a, 'activity_type', 'unknown') for a in activities))
        variety_score = min(100, activity_types * 20)
        
        # Calculate weighted score
        engagement_score = (
            frequency_score * 0.4 +
            consistency_score * 0.3 +
            time_score * 0.2 +
            variety_score * 0.1
        )
        
        return round(engagement_score, 2)
    
    def _check_daily_active(self, activities: List) -> bool:
        """Check if user has logged activity today"""
        today = datetime.utcnow().date()
        return any(
            getattr(a, 'created_at', None) and 
            getattr(a, 'created_at').date() == today 
            for a in activities
        )
    
    def _calculate_consecutive_days(self, activities: List) -> int:
        """Calculate consecutive days active"""
        if not activities:
            return 0
        
        # Get unique dates
        dates = sorted(set(
            getattr(a, 'created_at', None).date() 
            for a in activities 
            if getattr(a, 'created_at', None)
        ), reverse=True)
        
        if not dates:
            return 0
        
        consecutive = 1
        for i in range(len(dates) - 1):
            if (dates[i] - dates[i + 1]).days == 1:
                consecutive += 1
            else:
                break
        
        return consecutive
    
    def _get_activity_breakdown(self, activities: List) -> Dict[str, int]:
        """Get breakdown of activities by type"""
        breakdown = {}
        for activity in activities:
            activity_type = getattr(activity, 'activity_type', 'unknown')
            breakdown[activity_type] = breakdown.get(activity_type, 0) + 1
        return breakdown
    
    def _generate_recommendations(self, engagement_score: float, breakdown: Dict) -> List[str]:
        """Generate recommendations based on engagement"""
        recommendations = []
        
        if engagement_score < 30:
            recommendations.append("Try to complete at least 2-3 activities per week to improve engagement")
        elif engagement_score < 60:
            recommendations.append("Keep up the good work! Consistency is key to maintaining engagement")
        else:
            recommendations.append("Excellent engagement! You're doing great!")
        
        # Activity type recommendations
        if 'quiz' not in breakdown:
            recommendations.append("Try completing some quizzes to improve learning")
        
        if 'challenge' not in breakdown:
            recommendations.append("Accept some challenges to earn more rewards")
        
        return recommendations
    
    def get_engagement_level(self, score: float) -> str:
        """Get engagement level based on score"""
        if score < 20:
            return "Beginner"
        elif score < 40:
            return "Active"
        elif score < 60:
            return "Engaged"
        elif score < 80:
            return "Highly Engaged"
        else:
            return "Power User"
    
    def predict_next_engagement_dip(self, activities: List) -> Dict[str, Any]:
        """Predict when user might lose engagement"""
        if len(activities) < 5:
            return {'prediction': 'Not enough data', 'days_until_dip': None}
        
        # Simple prediction: if no activity in last 3 days
        recent_activities = [a for a in activities 
                             if getattr(a, 'created_at', None) 
                             and getattr(a, 'created_at').date() 
                             >= (datetime.utcnow() - timedelta(days=3)).date()]
        
        if len(recent_activities) < 2:
            return {
                'prediction': 'High risk of disengagement',
                'days_until_dip': 1,
                'recommendation': 'Log in and complete an activity to maintain your streak'
            }
        
        return {
            'prediction': 'Engagement maintained',
            'days_until_dip': None,
            'recommendation': 'Keep maintaining your activity pattern'
        }
