"""
Validation Checklist Agent
Verifies challenge completion and provides validation checklists
"""

from typing import Dict, List, Any
from datetime import datetime


class ValidationAgent:
    """
    Validates user challenge completion and provides
    detailed checklists to ensure proper task completion.
    
    Validation Types:
    - Activity Validation
    - Challenge Completion Check
    - Quality Assessment
    - Goal Verification
    """
    
    def __init__(self):
        """Initialize validation agent"""
        self.name = "Validation Agent"
        self.version = "1.0"
        self.description = "Validates challenge completion and provides verification checklists"
        print(f"[{self.name}] Initialized")
    
    def get_validation_checklist(self, challenge: Dict) -> Dict[str, Any]:
        """
        Get validation checklist for a challenge
        
        Args:
            challenge: Challenge dictionary
            
        Returns:
            Validation checklist
        """
        checklist = []
        challenge_type = challenge.get('difficulty', 'medium')
        title = challenge.get('title', 'Challenge')
        
        # Generate checklist based on challenge type
        if 'Daily' in title or 'daily' in challenge_type.lower():
            checklist = self._get_daily_checklist(challenge)
        elif 'Weekly' in title or 'weekly' in challenge_type.lower():
            checklist = self._get_weekly_checklist(challenge)
        elif 'Skill' in title:
            checklist = self._get_skill_checklist(challenge)
        elif 'Streak' in title:
            checklist = self._get_streak_checklist(challenge)
        else:
            checklist = self._get_generic_checklist(challenge)
        
        return {
            'challenge_id': challenge.get('id'),
            'challenge_title': title,
            'checklist': checklist,
            'total_items': len(checklist),
            'completion_percentage': 0,
            'validation_level': self._determine_validation_level(challenge),
            'created_at': datetime.utcnow().isoformat()
        }
    
    def _get_daily_checklist(self, challenge: Dict) -> List[Dict[str, Any]]:
        """Get daily challenge checklist"""
        return [
            {
                'id': 1,
                'item': 'Log in to platform',
                'description': 'Successfully log into your account',
                'completed': False,
                'points': 5
            },
            {
                'id': 2,
                'item': 'Start one activity',
                'description': 'Begin a quiz, study session, or challenge',
                'completed': False,
                'points': 10
            },
            {
                'id': 3,
                'item': 'Spend minimum 15 minutes',
                'description': 'Maintain focus for at least 15 minutes',
                'completed': False,
                'points': 10
            },
            {
                'id': 4,
                'item': 'Complete the activity',
                'description': 'Successfully finish the session',
                'completed': False,
                'points': 10
            },
            {
                'id': 5,
                'item': 'Review your progress',
                'description': 'Check your stats and improvements',
                'completed': False,
                'points': 5,
                'optional': True
            }
        ]
    
    def _get_weekly_checklist(self, challenge: Dict) -> List[Dict[str, Any]]:
        """Get weekly challenge checklist"""
        return [
            {
                'id': 1,
                'item': 'Complete 3+ activities',
                'description': 'Finish at least 3 learning activities this week',
                'completed': False,
                'points': 20
            },
            {
                'id': 2,
                'item': 'Log in 5+ days',
                'description': 'Maintain activity for at least 5 days',
                'completed': False,
                'points': 20
            },
            {
                'id': 3,
                'item': 'Spend 60+ minutes',
                'description': 'Total learning time of at least 60 minutes',
                'completed': False,
                'points': 15
            },
            {
                'id': 4,
                'item': 'Try variety of activities',
                'description': 'Complete different types of activities (quiz, challenge, study)',
                'completed': False,
                'points': 15
            },
            {
                'id': 5,
                'item': 'Achieve 70%+ on quizzes',
                'description': 'Score at least 70% on quiz attempts',
                'completed': False,
                'points': 25
            }
        ]
    
    def _get_skill_checklist(self, challenge: Dict) -> List[Dict[str, Any]]:
        """Get skill development checklist"""
        return [
            {
                'id': 1,
                'item': 'Theory Learning',
                'description': 'Study and understand core concepts (3-4 hours)',
                'completed': False,
                'points': 25
            },
            {
                'id': 2,
                'item': 'Practice Exercises',
                'description': 'Complete 5+ practice exercises with 80%+ accuracy',
                'completed': False,
                'points': 30
            },
            {
                'id': 3,
                'item': 'Mini Projects',
                'description': 'Build 2-3 mini projects applying the skill',
                'completed': False,
                'points': 30
            },
            {
                'id': 4,
                'item': 'Quiz Assessment',
                'description': 'Pass the skill assessment quiz with 85%+ score',
                'completed': False,
                'points': 35
            },
            {
                'id': 5,
                'item': 'Reflection & Documentation',
                'description': 'Document what you learned and how to apply it',
                'completed': False,
                'points': 20
            }
        ]
    
    def _get_streak_checklist(self, challenge: Dict) -> List[Dict[str, Any]]:
        """Get streak maintenance checklist"""
        return [
            {
                'id': 1,
                'item': 'Daily Login (Day 1)',
                'description': 'Log in and complete one activity',
                'completed': False,
                'points': 5
            },
            {
                'id': 2,
                'item': 'Daily Login (Day 2-3)',
                'description': 'Maintain streak for 2-3 days',
                'completed': False,
                'points': 10
            },
            {
                'id': 3,
                'item': 'Daily Login (Day 4-5)',
                'description': 'Keep the streak alive for 4-5 days',
                'completed': False,
                'points': 15
            },
            {
                'id': 4,
                'item': 'Weekly Milestone (Day 7)',
                'description': 'Reach a full week of consecutive activity',
                'completed': False,
                'points': 25
            },
            {
                'id': 5,
                'item': 'Bonus Activities',
                'description': 'Complete extra challenges to boost streak value',
                'completed': False,
                'points': 20,
                'optional': True
            }
        ]
    
    def _get_generic_checklist(self, challenge: Dict) -> List[Dict[str, Any]]:
        """Get generic challenge checklist"""
        return [
            {
                'id': 1,
                'item': 'Understand Requirements',
                'description': 'Read and understand all challenge requirements',
                'completed': False,
                'points': 10
            },
            {
                'id': 2,
                'item': 'Plan Your Approach',
                'description': 'Create a plan to tackle the challenge',
                'completed': False,
                'points': 10
            },
            {
                'id': 3,
                'item': 'Execute Tasks',
                'description': 'Complete all required tasks',
                'completed': False,
                'points': 20
            },
            {
                'id': 4,
                'item': 'Verify Completion',
                'description': 'Check that all tasks are completed correctly',
                'completed': False,
                'points': 15
            },
            {
                'id': 5,
                'item': 'Submit & Review',
                'description': 'Submit your work and review feedback',
                'completed': False,
                'points': 15
            }
        ]
    
    def _determine_validation_level(self, challenge: Dict) -> str:
        """Determine validation level based on challenge"""
        difficulty = challenge.get('difficulty_level', 'medium')
        
        if difficulty == 'easy':
            return 'basic'
        elif difficulty == 'medium':
            return 'standard'
        elif difficulty == 'hard':
            return 'strict'
        else:
            return 'standard'
    
    def validate_challenge_completion(self, challenge: Dict, 
                                     completion_data: Dict) -> Dict[str, Any]:
        """
        Validate if a challenge is properly completed
        
        Args:
            challenge: Challenge dictionary
            completion_data: Data about completion attempt
            
        Returns:
            Validation result
        """
        checklist = self.get_validation_checklist(challenge)['checklist']
        
        # Validate against checklist
        validation_results = []
        for item in checklist:
            item_id = item.get('id')
            completed = completion_data.get(f'item_{item_id}', False)
            
            validation_results.append({
                'item_id': item_id,
                'item': item.get('item'),
                'expected': True,
                'actual': completed,
                'valid': completed or item.get('optional', False),
                'points': item.get('points', 0) if completed else 0
            })
        
        # Calculate overall validation
        total_required = len([v for v in validation_results if not v.get('optional', False)])
        completed_required = len([v for v in validation_results if v.get('valid')])
        
        is_valid = completed_required >= total_required * 0.8  # 80% threshold
        completion_percentage = (completed_required / total_required * 100) if total_required > 0 else 0
        total_points = sum(v.get('points', 0) for v in validation_results)
        
        return {
            'challenge_id': challenge.get('id'),
            'is_valid': is_valid,
            'completion_percentage': round(completion_percentage, 1),
            'items_completed': completed_required,
            'items_total': total_required,
            'validation_details': validation_results,
            'points_earned': total_points,
            'validation_message': self._get_validation_message(is_valid, completion_percentage),
            'validated_at': datetime.utcnow().isoformat()
        }
    
    def _get_validation_message(self, is_valid: bool, completion: float) -> str:
        """Get validation message"""
        if is_valid:
            if completion >= 95:
                return "Perfect! Challenge completed with flying colors!"
            elif completion >= 85:
                return "Great job! Challenge successfully completed!"
            else:
                return "Challenge completed! Well done!"
        else:
            if completion >= 70:
                return "Almost there! Complete the remaining items to finish this challenge."
            else:
                return "You've started well. Continue working on the remaining tasks."
    
    def get_quality_assessment(self, completion_data: Dict) -> Dict[str, Any]:
        """
        Assess quality of work beyond checklist
        
        Args:
            completion_data: Completion data dictionary
            
        Returns:
            Quality assessment
        """
        return {
            'accuracy_score': completion_data.get('accuracy', 75),
            'time_efficiency': completion_data.get('time_efficiency', 'good'),
            'creativity_bonus': completion_data.get('creativity_bonus', 0),
            'effort_level': completion_data.get('effort_level', 'good'),
            'quality_feedback': self._get_quality_feedback(completion_data),
            'bonus_points': self._calculate_bonus_points(completion_data)
        }
    
    def _get_quality_feedback(self, data: Dict) -> str:
        """Get quality feedback"""
        accuracy = data.get('accuracy', 0)
        
        if accuracy >= 95:
            return "Exceptional work! Your attention to detail is impressive."
        elif accuracy >= 85:
            return "Great quality! Keep maintaining these standards."
        elif accuracy >= 75:
            return "Good job! There's room for improvement in some areas."
        else:
            return "Keep practicing! Accuracy will improve with more effort."
    
    def _calculate_bonus_points(self, data: Dict) -> int:
        """Calculate bonus points for quality"""
        bonus = 0
        
        if data.get('accuracy', 0) >= 95:
            bonus += 10
        if data.get('time_efficiency', '') == 'excellent':
            bonus += 5
        if data.get('creativity_bonus', 0) > 0:
            bonus += data.get('creativity_bonus', 0)
        if data.get('effort_level', '') == 'excellent':
            bonus += 10
        
        return bonus
