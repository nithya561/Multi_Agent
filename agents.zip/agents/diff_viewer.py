"""
Diff Viewer Agent
Compares user metrics and shows progress differences
"""

from typing import Dict, List, Any
from datetime import datetime


class DiffViewer:
    """
    Visualizes differences between user metrics at different time points.
    Helps track progress and show improvements from optimizations.
    """
    
    def __init__(self):
        """Initialize diff viewer agent"""
        self.name = "Diff Viewer Agent"
        self.version = "1.0"
        self.description = "Compares metrics and visualizes progress differences"
        print(f"[{self.name}] Initialized")
    
    def compare_metrics(self, before: Dict[str, Any], after: Dict[str, Any]) -> Dict[str, Any]:
        """
        Compare two metric snapshots
        
        Args:
            before: Previous metrics dictionary
            after: Current metrics dictionary
            
        Returns:
            Detailed comparison
        """
        return {
            'engagement_score': self._compare_scores(
                before.get('engagement_score', 0), 
                after.get('engagement_score', 0)
            ),
            'activities_count': self._compare_counts(
                before.get('activities_count', 0),
                after.get('activities_count', 0)
            ),
            'total_time_minutes': self._compare_counts(
                before.get('total_time_minutes', 0),
                after.get('total_time_minutes', 0)
            ),
            'overall_trend': self._calculate_overall_trend(before, after),
            'insights': self._generate_insights(before, after),
            'visualization': self._generate_visualization_data(before, after),
            'comparison_timestamp': datetime.utcnow().isoformat()
        }
    
    def _compare_scores(self, before: float, after: float) -> Dict[str, Any]:
        """Compare two scores"""
        difference = after - before
        percentage_change = (difference / before * 100) if before > 0 else 0
        
        return {
            'before': round(before, 2),
            'after': round(after, 2),
            'difference': round(difference, 2),
            'percentage_change': round(percentage_change, 1),
            'trend': 'up' if difference > 0 else 'down' if difference < 0 else 'stable',
            'change_description': self._get_change_description(difference, 'engagement'),
            'status': '📈' if difference > 0 else '📉' if difference < 0 else '➡️'
        }
    
    def _compare_counts(self, before: int, after: int) -> Dict[str, Any]:
        """Compare two counts"""
        difference = after - before
        percentage_change = (difference / before * 100) if before > 0 else (100 if after > 0 else 0)
        
        return {
            'before': before,
            'after': after,
            'difference': difference,
            'percentage_change': round(percentage_change, 1),
            'trend': 'up' if difference > 0 else 'down' if difference < 0 else 'stable',
            'change_description': self._get_change_description(difference, 'count'),
            'status': '📈' if difference > 0 else '📉' if difference < 0 else '➡️'
        }
    
    def _get_change_description(self, change: float, metric_type: str) -> str:
        """Get description for change"""
        if metric_type == 'engagement':
            if change > 20:
                return 'Significant improvement! 🎉'
            elif change > 10:
                return 'Great progress!'
            elif change > 0:
                return 'Positive trend'
            elif change < -20:
                return 'Attention needed'
            elif change < -10:
                return 'Declining trend'
            else:
                return 'Slight decrease'
        
        elif metric_type == 'count':
            if change >= 5:
                return 'Substantial increase'
            elif change >= 1:
                return 'Increased'
            elif change == 0:
                return 'No change'
            else:
                return 'Decreased'
        
        return 'Change recorded'
    
    def _calculate_overall_trend(self, before: Dict, after: Dict) -> Dict[str, Any]:
        """Calculate overall trend"""
        engagement_before = before.get('engagement_score', 0)
        engagement_after = after.get('engagement_score', 0)
        activities_before = before.get('activities_count', 0)
        activities_after = after.get('activities_count', 0)
        
        engagement_change = engagement_after - engagement_before
        activities_change = activities_after - activities_before
        
        # Determine overall trend
        if engagement_change > 0 and activities_change > 0:
            trend = 'strong_upward'
            sentiment = 'Excellent improvement'
        elif engagement_change > 0 or activities_change > 0:
            trend = 'upward'
            sentiment = 'Good progress'
        elif engagement_change < 0 or activities_change < 0:
            trend = 'downward'
            sentiment = 'Needs attention'
        else:
            trend = 'stable'
            sentiment = 'Stable performance'
        
        return {
            'trend': trend,
            'sentiment': sentiment,
            'emoji': self._get_trend_emoji(trend),
            'recommendation': self._get_trend_recommendation(trend)
        }
    
    def _get_trend_emoji(self, trend: str) -> str:
        """Get emoji for trend"""
        emojis = {
            'strong_upward': '🚀',
            'upward': '📈',
            'stable': '➡️',
            'downward': '📉'
        }
        return emojis.get(trend, '📊')
    
    def _get_trend_recommendation(self, trend: str) -> str:
        """Get recommendation based on trend"""
        recommendations = {
            'strong_upward': 'Keep up the excellent work! You\'re on fire! 🔥',
            'upward': 'Great momentum! Continue with your current pace.',
            'stable': 'Maintain consistency. Try pushing a bit harder.',
            'downward': 'Let\'s reverse this trend. Take on new challenges!'
        }
        return recommendations.get(trend, 'Keep improving!')
    
    def _generate_insights(self, before: Dict, after: Dict) -> List[str]:
        """Generate insights from comparison"""
        insights = []
        
        engagement_change = after.get('engagement_score', 0) - before.get('engagement_score', 0)
        activities_change = after.get('activities_count', 0) - before.get('activities_count', 0)
        time_change = after.get('total_time_minutes', 0) - before.get('total_time_minutes', 0)
        
        # Engagement insights
        if engagement_change > 15:
            insights.append('Engagement skyrocketed! Your optimization strategy is working!')
        elif engagement_change > 5:
            insights.append('Engagement improved. Keep this momentum going!')
        elif engagement_change < -15:
            insights.append('Engagement has dropped significantly. Time to refocus!')
        
        # Activity insights
        if activities_change > 0:
            insights.append(f'You completed {activities_change} more activities than before.')
        
        # Time insights
        if time_change > 60:
            insights.append(f'You invested {time_change // 60} more hours. That\'s dedication!')
        elif time_change > 0:
            insights.append(f'You spent {time_change} more minutes learning. Every minute counts!')
        
        if not insights:
            insights.append('Your metrics have been recorded. Work towards improvement!')
        
        return insights
    
    def _generate_visualization_data(self, before: Dict, after: Dict) -> Dict[str, Any]:
        """Generate data for visualization"""
        return {
            'bar_chart': {
                'labels': ['Engagement Score', 'Activities', 'Time (hours)'],
                'before': [
                    before.get('engagement_score', 0),
                    before.get('activities_count', 0),
                    round(before.get('total_time_minutes', 0) / 60, 1)
                ],
                'after': [
                    after.get('engagement_score', 0),
                    after.get('activities_count', 0),
                    round(after.get('total_time_minutes', 0) / 60, 1)
                ]
            },
            'improvement_percentage': self._calculate_improvement_percentage(before, after),
            'chart_title': 'Before vs After Comparison'
        }
    
    def _calculate_improvement_percentage(self, before: Dict, after: Dict) -> float:
        """Calculate overall improvement percentage"""
        engagement_before = before.get('engagement_score', 1)
        engagement_after = after.get('engagement_score', 0)
        
        if engagement_before == 0:
            return 100.0 if engagement_after > 0 else 0.0
        
        improvement = ((engagement_after - engagement_before) / engagement_before) * 100
        return round(max(-100, improvement), 1)
    
    def generate_progress_report(self, user: Dict, metrics: List) -> Dict[str, Any]:
        """
        Generate comprehensive progress report
        
        Args:
            user: User dictionary
            metrics: List of engagement metrics over time
            
        Returns:
            Progress report
        """
        if len(metrics) < 2:
            return {
                'status': 'Not enough data',
                'message': 'We need at least 2 data points to generate a report'
            }
        
        # Sort metrics by time
        sorted_metrics = sorted(metrics, key=lambda m: getattr(m, 'recorded_at', datetime.utcnow()))
        
        earliest = sorted_metrics[0]
        latest = sorted_metrics[-1]
        
        # Generate comparison
        comparison = self.compare_metrics(
            earliest.to_dict() if hasattr(earliest, 'to_dict') else earliest,
            latest.to_dict() if hasattr(latest, 'to_dict') else latest
        )
        
        # Calculate statistics
        all_scores = [getattr(m, 'engagement_score', 0) for m in sorted_metrics]
        all_activities = [getattr(m, 'activities_count', 0) for m in sorted_metrics]
        
        return {
            'user': user.get('username', 'User'),
            'report_type': 'Progress Report',
            'period': {
                'start': getattr(earliest, 'recorded_at', datetime.utcnow()).isoformat(),
                'end': getattr(latest, 'recorded_at', datetime.utcnow()).isoformat()
            },
            'comparison': comparison,
            'statistics': {
                'average_engagement': round(sum(all_scores) / len(all_scores), 2) if all_scores else 0,
                'peak_engagement': max(all_scores) if all_scores else 0,
                'min_engagement': min(all_scores) if all_scores else 0,
                'average_activities': round(sum(all_activities) / len(all_activities), 1) if all_activities else 0,
                'data_points': len(metrics)
            },
            'summary': self._generate_report_summary(comparison),
            'generated_at': datetime.utcnow().isoformat()
        }
    
    def _generate_report_summary(self, comparison: Dict) -> str:
        """Generate report summary"""
        engagement = comparison.get('engagement_score', {})
        trend = comparison.get('overall_trend', {})
        
        summary = f"Your engagement score has {engagement.get('trend', 'remained stable')} "
        summary += f"by {abs(engagement.get('difference', 0)):.1f} points "
        summary += f"({engagement.get('percentage_change', 0):.1f}%). "
        summary += f"Overall trend: {trend.get('sentiment', 'Stable')}. "
        summary += trend.get('recommendation', 'Keep working!')
        
        return summary
    
    def get_detailed_diff(self, before: Dict, after: Dict) -> List[Dict[str, Any]]:
        """Get detailed diff of all changes"""
        diffs = []
        
        # Get all keys from both dictionaries
        all_keys = set(before.keys()) | set(after.keys())
        
        for key in sorted(all_keys):
            before_val = before.get(key, 'N/A')
            after_val = after.get(key, 'N/A')
            
            if before_val != after_val:
                diffs.append({
                    'key': key,
                    'before': before_val,
                    'after': after_val,
                    'change_type': 'added' if key not in before else 'modified' if key not in after else 'modified'
                })
        
        return diffs
